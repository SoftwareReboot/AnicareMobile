package com.anicarebackend.anicare;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AnicareApplicationTests {

	@Test
	void contextLoads() {
	}

}
