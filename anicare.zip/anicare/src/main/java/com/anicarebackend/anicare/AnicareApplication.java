package com.anicarebackend.anicare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnicareApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnicareApplication.class, args);
	}

}
